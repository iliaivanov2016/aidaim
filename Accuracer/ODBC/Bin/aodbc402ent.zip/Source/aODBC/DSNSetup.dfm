object DSNsetupForm: TDSNsetupForm
  Left = 289
  Top = 90
  BorderStyle = bsDialog
  Caption = 'Accuracer ODBC DSN Setup'
  ClientHeight = 580
  ClientWidth = 440
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Visible = True
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 8
    Top = 10
    Width = 94
    Height = 13
    Caption = 'Data Source Name:'
  end
  object Label2: TLabel
    Left = 8
    Top = 43
    Width = 56
    Height = 13
    Caption = 'Description:'
  end
  object OK: TBitBtn
    Left = 360
    Top = 8
    Width = 75
    Height = 25
    Caption = 'OK'
    TabOrder = 0
    OnClick = OKClick
  end
  object Cancel: TBitBtn
    Left = 360
    Top = 40
    Width = 75
    Height = 25
    Caption = 'Cancel'
    TabOrder = 1
    OnClick = CancelClick
  end
  object Help: TBitBtn
    Left = 360
    Top = 86
    Width = 75
    Height = 25
    Caption = 'Help'
    TabOrder = 2
    OnClick = HelpClick
  end
  object DSN: TEdit
    Left = 112
    Top = 8
    Width = 233
    Height = 21
    TabOrder = 3
  end
  object Description: TEdit
    Left = 112
    Top = 40
    Width = 233
    Height = 21
    TabOrder = 4
    Text = 'Accuracer database'
  end
  object Mode: TRadioGroup
    Left = 8
    Top = 73
    Width = 337
    Height = 33
    Caption = 'Mode'
    Columns = 2
    ItemIndex = 0
    Items.Strings = (
      'Client-Server'
      'File-Server')
    TabOrder = 5
    OnClick = ModeClick
    OnEnter = ModeClick
  end
  object ConnectParams: TGroupBox
    Left = 8
    Top = 121
    Width = 425
    Height = 80
    Caption = 'Connection parameters'
    TabOrder = 7
    object Label3: TLabel
      Left = 8
      Top = 22
      Width = 83
      Height = 13
      Caption = 'Datasource Path:'
      Visible = False
    end
    object Label4: TLabel
      Left = 9
      Top = 22
      Width = 63
      Height = 13
      Caption = 'Remote host:'
    end
    object Label5: TLabel
      Left = 258
      Top = 22
      Width = 61
      Height = 13
      Caption = 'Remote port:'
    end
    object Label6: TLabel
      Left = 258
      Top = 49
      Width = 50
      Height = 13
      Caption = 'Local port:'
    end
    object Label7: TLabel
      Left = 9
      Top = 49
      Width = 78
      Height = 13
      Caption = 'Database name:'
    end
    object Dir: TBitBtn
      Left = 388
      Top = 17
      Width = 25
      Height = 25
      Caption = '...'
      TabOrder = 0
      Visible = False
      OnClick = DirClick
    end
    object DatabaseFile: TEdit
      Left = 102
      Top = 19
      Width = 274
      Height = 21
      TabOrder = 1
      Visible = False
    end
    object RemoteHost: TEdit
      Left = 92
      Top = 19
      Width = 148
      Height = 21
      TabOrder = 2
    end
    object RemotePort: TEdit
      Left = 324
      Top = 19
      Width = 90
      Height = 21
      TabOrder = 3
    end
    object LocalPort: TEdit
      Left = 324
      Top = 46
      Width = 90
      Height = 21
      TabOrder = 5
    end
    object DatabaseName: TEdit
      Left = 92
      Top = 46
      Width = 148
      Height = 21
      TabOrder = 4
    end
  end
  object NetworkParams: TGroupBox
    Left = 8
    Top = 211
    Width = 425
    Height = 215
    Caption = 'Network parameters'
    TabOrder = 8
    object NetworkCompression: TGroupBox
      Left = 2
      Top = 15
      Width = 421
      Height = 48
      Align = alTop
      Caption = 'Traffic compression'
      TabOrder = 0
      object Label8: TLabel
        Left = 9
        Top = 20
        Width = 109
        Height = 13
        Caption = 'Compression Algorithm:'
      end
      object Label9: TLabel
        Left = 223
        Top = 20
        Width = 93
        Height = 13
        Caption = 'Compression Mode:'
      end
      object CompressionAlgorithm: TComboBox
        Left = 127
        Top = 18
        Width = 63
        Height = 21
        ItemHeight = 13
        ItemIndex = 0
        TabOrder = 0
        Text = 'none'
        Items.Strings = (
          'none'
          'ZLIB'
          'BZIP'
          'PPM')
      end
      object CompressionMode: TComboBox
        Left = 322
        Top = 18
        Width = 89
        Height = 21
        ItemHeight = 13
        ItemIndex = 0
        TabOrder = 1
        Text = '1 - fastest'
        Items.Strings = (
          '1 - fastest'
          '2'
          '3'
          '4'
          '5 - middle'
          '6'
          '7'
          '8'
          '9 - best rate')
      end
    end
    object NetworkEncryption: TGroupBox
      Left = 2
      Top = 70
      Width = 421
      Height = 137
      Caption = 'Traffic encryption'
      TabOrder = 1
      object Label1142: TLabel
        Left = 7
        Top = 55
        Width = 30
        Height = 13
        Caption = 'Mode:'
      end
      object Label1132: TLabel
        Left = 7
        Top = 23
        Width = 46
        Height = 13
        Caption = 'Algorithm:'
      end
      object IsInitVector2: TCheckBox
        Left = 7
        Top = 85
        Width = 146
        Height = 14
        Caption = 'Use initial vector from file:'
        Enabled = False
        TabOrder = 4
        OnClick = IsInitVector2Click
      end
      object cbMode2: TComboBox
        Left = 62
        Top = 51
        Width = 134
        Height = 21
        Style = csDropDownList
        Enabled = False
        ItemHeight = 13
        ItemIndex = 0
        TabOrder = 5
        Text = 'CTS'
        Items.Strings = (
          'CTS'
          'CBC'
          'CFB'
          'OFB')
      end
      object cbAlgorithm2: TComboBox
        Left = 62
        Top = 19
        Width = 134
        Height = 21
        Style = csDropDownList
        ItemHeight = 13
        ItemIndex = 0
        TabOrder = 2
        Text = 'none'
        OnChange = cbAlgorithm2Change
        Items.Strings = (
          'none'
          'Rijndael 128'
          'Rijndael 256'
          'Blowfish'
          'Twofish 128'
          'Twofish 256'
          'Square'
          'DES Single 8'
          'DES Double 8'
          'DES Double 16'
          'DES Triple 8'
          'DES Triple 16'
          'DES Triple 24')
      end
      object EncryptPageControl2: TPageControl
        Left = 205
        Top = 15
        Width = 210
        Height = 112
        ActivePage = BasicEncr2
        Enabled = False
        MultiLine = True
        TabOrder = 3
        object BasicEncr2: TTabSheet
          Caption = 'Basic encryption'
          object Label1122: TLabel
            Left = 5
            Top = 0
            Width = 49
            Height = 13
            Alignment = taCenter
            Caption = 'Password:'
          end
          object Label1172: TLabel
            Left = 5
            Top = 41
            Width = 85
            Height = 13
            Alignment = taCenter
            Caption = 'Retype password:'
          end
          object tPassword2: TEdit
            Left = 5
            Top = 16
            Width = 191
            Height = 21
            PasswordChar = '*'
            TabOrder = 0
          end
          object tRPassword2: TEdit
            Left = 5
            Top = 57
            Width = 191
            Height = 21
            PasswordChar = '*'
            TabOrder = 1
          end
        end
        object AdvEncr2: TTabSheet
          Caption = 'Advanced encryption'
          ImageIndex = 1
          object Label11112: TLabel
            Left = 7
            Top = 2
            Width = 69
            Height = 13
            Caption = 'Key file name: '
          end
          object KeyFileName2: TEdit
            Left = 8
            Top = 20
            Width = 156
            Height = 21
            TabOrder = 0
          end
          object SelectKey2: TButton
            Left = 171
            Top = 18
            Width = 25
            Height = 24
            Caption = '...'
            TabOrder = 1
            OnClick = SelectKey2Click
          end
        end
      end
      object IVFileName2: TEdit
        Left = 7
        Top = 104
        Width = 153
        Height = 21
        Enabled = False
        TabOrder = 0
      end
      object SelectInitVector2: TButton
        Left = 169
        Top = 102
        Width = 25
        Height = 25
        Caption = '...'
        Enabled = False
        TabOrder = 1
        OnClick = SelectInitVector2Click
      end
    end
  end
  object DatabaseSettings: TGroupBox
    Left = 8
    Top = 436
    Width = 425
    Height = 137
    Caption = 'Database encryption'
    TabOrder = 6
    object Label114: TLabel
      Left = 7
      Top = 55
      Width = 30
      Height = 13
      Caption = 'Mode:'
    end
    object Label113: TLabel
      Left = 7
      Top = 23
      Width = 46
      Height = 13
      Caption = 'Algorithm:'
    end
    object IsInitVector: TCheckBox
      Left = 7
      Top = 85
      Width = 146
      Height = 14
      Caption = 'Use initial vector from file:'
      Enabled = False
      TabOrder = 4
      OnClick = IsInitVectorClick
    end
    object cbMode: TComboBox
      Left = 62
      Top = 51
      Width = 134
      Height = 21
      Style = csDropDownList
      Enabled = False
      ItemHeight = 13
      ItemIndex = 0
      TabOrder = 5
      Text = 'CTS'
      Items.Strings = (
        'CTS'
        'CBC'
        'CFB'
        'OFB')
    end
    object cbAlgorithm: TComboBox
      Left = 62
      Top = 19
      Width = 134
      Height = 21
      Style = csDropDownList
      ItemHeight = 13
      ItemIndex = 0
      TabOrder = 2
      Text = 'none'
      OnChange = cbAlgorithmChange
      Items.Strings = (
        'none'
        'Rijndael 128'
        'Rijndael 256'
        'Blowfish'
        'Twofish 128'
        'Twofish 256'
        'Square'
        'DES Single 8'
        'DES Double 8'
        'DES Double 16'
        'DES Triple 8'
        'DES Triple 16'
        'DES Triple 24')
    end
    object EncryptPageControl: TPageControl
      Left = 205
      Top = 15
      Width = 210
      Height = 112
      ActivePage = AdvEncr
      Enabled = False
      MultiLine = True
      TabOrder = 3
      OnChange = EncryptPageControlChange
      object BasicEncr: TTabSheet
        Caption = 'Basic encryption'
        object Label112: TLabel
          Left = 5
          Top = 0
          Width = 49
          Height = 13
          Alignment = taCenter
          Caption = 'Password:'
        end
        object Label117: TLabel
          Left = 5
          Top = 41
          Width = 85
          Height = 13
          Alignment = taCenter
          Caption = 'Retype password:'
        end
        object tPassword: TEdit
          Left = 5
          Top = 16
          Width = 191
          Height = 21
          PasswordChar = '*'
          TabOrder = 0
        end
        object tRPassword: TEdit
          Left = 5
          Top = 57
          Width = 191
          Height = 21
          PasswordChar = '*'
          TabOrder = 1
        end
      end
      object AdvEncr: TTabSheet
        Caption = 'Advanced encryption'
        ImageIndex = 1
        object Label1111: TLabel
          Left = 7
          Top = 2
          Width = 69
          Height = 13
          Caption = 'Key file name: '
        end
        object KeyFileName: TEdit
          Left = 8
          Top = 20
          Width = 156
          Height = 21
          TabOrder = 0
        end
        object SelectKey: TButton
          Left = 171
          Top = 18
          Width = 25
          Height = 24
          Caption = '...'
          TabOrder = 1
          OnClick = SelectKeyClick
        end
      end
    end
    object IVFileName: TEdit
      Left = 7
      Top = 104
      Width = 153
      Height = 21
      Enabled = False
      TabOrder = 0
    end
    object SelectInitVector: TButton
      Left = 169
      Top = 102
      Width = 25
      Height = 25
      Caption = '...'
      Enabled = False
      TabOrder = 1
      OnClick = SelectInitVectorClick
    end
  end
  object SelectInitFile2: TOpenDialog
    DefaultExt = '.iv'
    Filter = 'Accuracer initial vector file (*.iv)|*.iv|All files|*.*'
    Title = 'Select Initial Vector File'
    Left = 129
    Top = 539
  end
  object SelectKeyFile2: TOpenDialog
    DefaultExt = '.key'
    Filter = 'Accuracer key file (*.key)|*.key|All files|*.*'
    Title = 'Select Key File'
    Left = 346
    Top = 494
  end
  object SelectDatabase: TOpenDialog
    DefaultExt = '.adb'
    Filter = 'Accuracer database file (*.adb)|*.adb|All files (*.*)|*.*'
    Title = 'Select Database File'
    Left = 352
    Top = 144
  end
  object SelectInitFile: TOpenDialog
    DefaultExt = '.iv'
    Filter = 'Accuracer initial vector file (*.iv)|*.iv|All files|*.*'
    Title = 'Select Initial Vector File'
    Left = 129
    Top = 539
  end
  object SelectKeyFile: TOpenDialog
    DefaultExt = '.key'
    Filter = 'Accuracer key file (*.key)|*.key|All files|*.*'
    Title = 'Select Key File'
    Left = 346
    Top = 494
  end
  object ACRDatabase1: TACRDatabase
    FormatVersion = 5.150000000000000000
    DatabaseName = 'AccuracerDB_1464693057'
    InMemory = False
    SessionName = 'Default'
    Exclusive = False
    BackupParams.CompressionAlgorithm = caNone
    BackupParams.CompressionMode = 1
    BackupParams.CryptoParams.CryptoAlgorithm = craNone
    BackupParams.CryptoParams.CryptoMode = acmCTS
    BackupParams.CryptoParams.KeySize = 56
    BackupParams.CryptoParams.Password = 'ACRpassword'
    BackupParams.CryptoParams.UseInitVector = False
    BackupParams.CryptoParams.InitVectorSize = 0
    BackupParams.BlockSize = 102400
    ConnectionParams.RemoteHost = '127.0.0.1'
    ConnectionParams.RemotePort = 12007
    ConnectionParams.LocalPort = 12008
    ConnectionParams.DatabaseName = 'DBDemos'
    ConnectionParams.CompressionAlgorithm = caNone
    ConnectionParams.CompressionMode = 1
    ConnectionParams.CryptoParams.CryptoAlgorithm = craNone
    ConnectionParams.CryptoParams.CryptoMode = acmCTS
    ConnectionParams.CryptoParams.KeySize = 56
    ConnectionParams.CryptoParams.Password = 'ACRpassword'
    ConnectionParams.CryptoParams.UseInitVector = False
    ConnectionParams.CryptoParams.InitVectorSize = 0
    ConnectionParams.ServerID = 0
    ConnectionParams.NetworkSettings.PacketSize = 8192
    ConnectionParams.NetworkSettings.MaxThreadCount = 100
    ConnectionParams.NetworkSettings.ConnectionParamsTunning = False
    ConnectionParams.NetworkSettings.TestPacketCount = 8
    ConnectionParams.NetworkSettings.DisconnectRetryCount = 12
    ConnectionParams.NetworkSettings.DisconnectDelay = 300
    ConnectionParams.NetworkSettings.CommandRetryCount = 5
    ConnectionParams.NetworkSettings.ReceiveTimeOut = 600000
    ConnectionParams.NetworkSettings.ReceiveSleep = 1
    ConnectionParams.NetworkSettings.MinSendTimeOut = 10000
    ConnectionParams.NetworkSettings.SendTimeOut = 180000
    ConnectionParams.NetworkSettings.WaitForSendSleep = 0
    ConnectionParams.NetworkSettings.ResendDelay = 300
    ConnectionParams.NetworkSettings.RequestDelay = 300
    ConnectionParams.NetworkSettings.WaitForTimeOut = 120000
    ConnectionParams.NetworkSettings.ThreadsTerminateDelay = 30000
    ConnectionParams.NetworkSettings.StartReceiveTimeOut = 60000
    ConnectionParams.NetworkSettings.RestoreDefaultSettings = ACRLocal
    ConnectionParams.NetworkSettings.ConnectRetryCount = 20
    ConnectionParams.NetworkSettings.ConnectDelay = 500
    ConnectionParams.NetworkSettings.UseServerSettings = False
    LockParams.Delay = 500
    LockParams.RetryCount = 20
    Options.MaxSessionCount = 367
    Options.PageSize = 4096
    Options.ExtentPageCount = 8
    Options.RandomSearchRetryCount = 10
    CryptoParams.CryptoAlgorithm = craNone
    CryptoParams.CryptoMode = acmCTS
    CryptoParams.KeySize = 56
    CryptoParams.Password = 'ACRpassword'
    CryptoParams.UseInitVector = False
    CryptoParams.InitVectorSize = 0
    Left = 122
    Top = 367
  end
end
