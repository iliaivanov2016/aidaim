//---------------------------------------------------------------------------
#include "main.h"
#include "string.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "EasyTable"
#pragma resource "*.dfm"
TCustomerInfoModule *CustomerInfoModule;

//---------------------------------------------------------------------------
__fastcall TCustomerInfoModule::TCustomerInfoModule(TComponent* Owner)
	: TWebModule(Owner)
{
  DllFileName.SetLength(260);
  GetModuleFileName(HInstance, (char*)(DllFileName.c_str()), 260);
}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::CustomerInfoModuleGetImageAction(
      TObject *Sender, TWebRequest *Request, TWebResponse *Response,
      bool &Handled)
{
  TJPEGImage *Jpg = new TJPEGImage();
  TMemoryStream *S = new TMemoryStream();
  TPicture *P = new TPicture();
  int ID;

  // First, make sure that we are at the correct image by moving to that ID
  // in the table.
  ID = StrToIntDef(Request->QueryFields->Values["id"], -1);
  BioLife->DatabaseFileName = ExtractFilePath(DllFileName) + "DBFishes.edb";
  BioLife->Open();
  Set<TLocateOption,0,1> flags;
  if (!BioLife->Locate("Species No", ID, flags))
    throw Exception("Could not locate image ID");
  try
  {
    P->Assign(BioLifeGraphic);
    Jpg->Assign(P->Graphic);
    try
    {
      Jpg->SaveToStream(S);
      S->Position = 0;
      Response->ContentType = AnsiString("image/jpeg");
      Response->ContentStream = S;
      Response->SendResponse();
    }
    __finally
    {
      &P->Free;
      &S->Free;
    }
  }
  __finally
  {
    &Jpg->Free;
  }

}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::CustomerInfoModuleBioLifeAction(
      TObject *Sender, TWebRequest *Request, TWebResponse *Response,
      bool &Handled)
{
  BioLife->DatabaseFileName = ExtractFilePath(DllFileName) + "DBFishes.edb";
  BioLife->Open();
  try
  {
    Response->Content = BioLifeProducer->Content();
  }
  catch(...)
  {
    BioLife->Close();
  }
}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::RootHTMLTag(TObject *Sender, TTag Tag,
      const AnsiString TagString, TStrings *TagParams,
      AnsiString &ReplaceText)
{
  if ( TagString==AnsiString("MODULENAME") )
    ReplaceText = Request->ScriptName;
}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::BioLifeNotesGetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
   Text = Sender->Value;
}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::BioLifeGraphicGetText(TField *Sender,
      AnsiString &Text, bool DisplayText)
{
  Text = Format("<IMG SRC=""%s/getimage?id=%d"" alt=""[%s]"" border=0>",
    ARRAYOFCONST((Request->ScriptName, BioLifeSpeciesNo->AsInteger, BioLifeCommon_Name->Text)));
}
//---------------------------------------------------------------------------
void __fastcall TCustomerInfoModule::CustomerInfoModulerootAction(
      TObject *Sender, TWebRequest *Request, TWebResponse *Response,
      bool &Handled)
{
  Response->Content = Root->Content();
}
//---------------------------------------------------------------------------
