//---------------------------------------------------------------------------
#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <HTTPApp.hpp>
#include "EasyTable.hpp"
#include <Db.hpp>
#include <DBWeb.hpp>
#include <SysInit.hpp>
#include <System.hpp>
#include <Controls.hpp>
#include <Dialogs.hpp>
#include <DSProd.hpp>
#include <Forms.hpp>
#include <Graphics.hpp>
#include <JPeg.hpp>
#include <Messages.hpp>
#include <Windows.hpp>

//---------------------------------------------------------------------------
class TCustomerInfoModule : public TWebModule
{
__published:	// IDE-managed Components
        TPageProducer *Root;
        TDataSetPageProducer *BioLifeProducer;
        TEasyTable *BioLife;
        TFloatField *BioLifeSpeciesNo;
        TStringField *BioLifeCategory;
        TStringField *BioLifeCommon_Name;
        TStringField *BioLifeSpeciesName;
        TFloatField *BioLifeLengthcm;
        TFloatField *BioLifeLength_In;
        TMemoField *BioLifeNotes;
        TGraphicField *BioLifeGraphic;
        TAutoIncField *BioLifeid;
        TEasySession *EasySession1;
        void __fastcall CustomerInfoModuleGetImageAction(TObject *Sender,
          TWebRequest *Request, TWebResponse *Response, bool &Handled);
        void __fastcall CustomerInfoModuleBioLifeAction(TObject *Sender,
          TWebRequest *Request, TWebResponse *Response, bool &Handled);
        void __fastcall RootHTMLTag(TObject *Sender, TTag Tag,
          const AnsiString TagString, TStrings *TagParams,
          AnsiString &ReplaceText);
        void __fastcall BioLifeNotesGetText(TField *Sender,
          AnsiString &Text, bool DisplayText);
        void __fastcall BioLifeGraphicGetText(TField *Sender,
          AnsiString &Text, bool DisplayText);
        void __fastcall CustomerInfoModulerootAction(TObject *Sender,
          TWebRequest *Request, TWebResponse *Response, bool &Handled);
private:	// User declarations
          AnsiString DllFileName;
public:		// User declarations
	__fastcall TCustomerInfoModule(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCustomerInfoModule *CustomerInfoModule;
//---------------------------------------------------------------------------
#endif
